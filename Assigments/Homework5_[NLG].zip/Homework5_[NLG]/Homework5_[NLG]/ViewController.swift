//
//  ViewController.swift
//  Homework5_[NLG]
//
//  Created by Edwar Rivera on 5/1/18.
//  Copyright © 2018 NCLSolutions. All rights reserved.
//

import UIKit

class ViewController: UIViewController {
   
    var redColorViewModels: [ColorViewModel] = []
    var blueColorViewModels: [ColorViewModel] = []
    var randomColorViewModels: [ColorViewModel] = []

    @IBOutlet weak var segmentControl: UISegmentedControl!{
        didSet{
            segmentControl.addTarget(self, action: #selector(segmentControlValueChanged), for: UIControlEvents.valueChanged)
        }
    }
    
    @objc private func segmentControlValueChanged() {
        print(segmentControl.selectedSegmentIndex)
        tableView.reloadData()
        
    }
    @IBOutlet weak var tableView: UITableView!{
        didSet{
            tableView.delegate = self as UITableViewDelegate
            tableView.dataSource = self as UITableViewDataSource
        }
    }
    
    override func viewDidLoad() {
        super.viewDidLoad()
        
        title = "Color Table"
        redColorViewModels = ColorManager.generateRedColors(desired: 100)
        blueColorViewModels = ColorManager.generateBlueColors(desired: 100)
        randomColorViewModels = ColorManager.generateRandomColors(desired: 100)
        tableView.reloadData()
        // Do any additional setup after loading the view, typically from a nib.
    }

    override func didReceiveMemoryWarning() {
        super.didReceiveMemoryWarning()
        // Dispose of any resources that can be recreated.
    }


}

    extension ViewController: UITableViewDelegate{
    
    func tableView(_ tableView: UITableView, didSelectRowAt indexPath: IndexPath) {
        tableView.deselectRow(at: indexPath, animated: true)
        
    }
}
extension ViewController: UITableViewDataSource{
    func tableView(_ tableView: UITableView, numberOfRowsInSection section: Int) -> Int {
        return redColorViewModels.count
        
    }
    
    func tableView(_ tableView: UITableView, cellForRowAt indexPath: IndexPath) -> UITableViewCell {
        
        let colorViewModel: ColorViewModel
        let cell =  UITableViewCell(style: .subtitle, reuseIdentifier: nil)
        switch segmentControl.selectedSegmentIndex
        {
        case 0:
            colorViewModel = redColorViewModels[indexPath.row]
            cell.backgroundColor = colorViewModel.color
            cell.textLabel?.text = colorViewModel.name
            cell.textLabel?.textColor = UIColor .black
        case 1:
            colorViewModel = blueColorViewModels[indexPath.row]
            cell.backgroundColor = colorViewModel.color
            cell.textLabel?.text = colorViewModel.name
            cell.textLabel?.textColor = UIColor .black
        case 2:
            colorViewModel = randomColorViewModels[indexPath.row]
            cell.backgroundColor = colorViewModel.color
            cell.textLabel?.text = colorViewModel.name
            cell.textLabel?.textColor = UIColor .black
        default:
            break
        }
        
        return cell
    }
    
    func tableView(tableView: UITableView, didDeselectRowAtIndexPath indexPath: NSIndexPath) {
        if let cell = tableView.cellForRow(at: indexPath as IndexPath) {
            cell.accessoryType = .none
        }
    }
    
    func tableView(tableView: UITableView, didSelectRowAtIndexPath indexPath: NSIndexPath) {
        if let cell = tableView.cellForRow(at: indexPath as IndexPath) {
            cell.accessoryType = .checkmark
        }
    }
}

