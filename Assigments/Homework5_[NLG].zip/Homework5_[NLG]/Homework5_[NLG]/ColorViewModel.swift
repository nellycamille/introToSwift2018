//
//  ColorViewModel.swift
//  Homework5_[NLG]
//
//  Created by Edwar Rivera on 5/1/18.
//  Copyright © 2018 NCLSolutions. All rights reserved.
//

import UIKit

struct ColorViewModel {
    let name: String
    let color: UIColor
    let isSelected: Bool
}
